/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fu.testing.lab;

import java.util.Arrays;
import java.util.Collection;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

/**
 *
 * @author triet
 */
@RunWith(Parameterized.class)
public class CheckDayInMonthTest {

    public int inputMonth;
    public int inputYear;
    public int expectedResultDayInMonth;
    DateTimeCheckerLib instance;
    static int i = 0;

    public CheckDayInMonthTest(int inputMonth, int inputYear, int expectedResultDayInMonth) {
        this.inputMonth = inputMonth;
        this.inputYear = inputYear;
        this.expectedResultDayInMonth = expectedResultDayInMonth;
    }

    @Before
    public void setUp() {
        instance = new DateTimeCheckerLib();
    }

    @Parameterized.Parameters
    public static Collection dayInMonthList() {
        return Arrays.asList(new Object[][]{
            {1, 2019, 31}, {3, 1000, 31}, {5, 1004, 31}, {7, 2000, 31}, {8, 3000, 31}, {10, 2023, 31}, {12, 1999, 31},
            {4, 2222, 30}, {6, 1780, 30}, {9, 1999, 30}, {11, 2023, 30}, {2, 2000, 29}, {2, 2100, 28},
            {2, 1780, 29}, {2, 1999, 28}, {5, 999, 0}, {2, 3001, 0}//, { 12, "123a", 0 }, { 13, "", 0 }
        });
    }

    /**
     * Test of checkDayInMonth method, of class DateTimeCheckerLib.
     */
    @Test
    public void testCheckDayInMonth() {
        System.out.println("Day In Month " + "(" + i++ + "):  " + inputMonth + "/" + inputYear + " should return " + expectedResultDayInMonth);
        assertEquals(expectedResultDayInMonth, instance.checkDayInMonth(inputMonth, inputYear));
        System.out.println("Pass");
    }
}
