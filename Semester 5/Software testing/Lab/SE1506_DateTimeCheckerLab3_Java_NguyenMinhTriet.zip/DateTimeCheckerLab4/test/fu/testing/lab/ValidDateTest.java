/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fu.testing.lab;

import java.util.Arrays;
import java.util.Collection;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

/**
 *
 * @author triet
 */
@RunWith(Parameterized.class)
public class ValidDateTest {

    public int inputDate;
    public int inputMonth;
    public int inputYear;
    public boolean expectedResult;
    DateTimeCheckerLib instance;
    static int y = 0;

    public ValidDateTest(int inputDate, int inputMonth, int inputYear, boolean expectedResult) {
        this.inputDate = inputDate;
        this.inputMonth = inputMonth;
        this.inputYear = inputYear;
        this.expectedResult = expectedResult;
    }

    @Before
    public void setUp() {
        instance = new DateTimeCheckerLib();
    }

    @Parameterized.Parameters
    public static Collection validDateList() {
        return Arrays.asList(new Object[][]{
            {30, 0, 2021, false}, {31, 1, 2000, true}, {28, 12, 1400, true}, {29, 4, 1780, true}, {30, 4, 2001, true},
            {28, 2, 1400, true}, {1, 2, 1400, true}, {29, 2, 1400, false}, {29, 2, 1780, true}, {29, 2, 2000, true},
            {29, 2, 2001, false}, {28, 2, 2001, true}, {0, 1, 2000, false}, {32, 4, 1400, false}, {28, 13, 1400, false},
            {15, 2, 1000, true}, {30, 4, 3000, true}, {1, 12, 999, false}, {29, 1, 3001, false}//, { 1780, 12, "a",false }
        });
    }

    /**
     * Test of validDate method, of class DateTimeCheckerLib
     */
    @Test
    public void testIsValidDate() throws Exception {
        System.out.println("Is Valid Date (" + y++ + "): " + inputDate + "/" + inputMonth + "/" + inputYear + " should return " + expectedResult);
        assertEquals(expectedResult, instance.validDate(inputDate, inputMonth, inputYear));
        System.out.println("Pass");
    }
}
