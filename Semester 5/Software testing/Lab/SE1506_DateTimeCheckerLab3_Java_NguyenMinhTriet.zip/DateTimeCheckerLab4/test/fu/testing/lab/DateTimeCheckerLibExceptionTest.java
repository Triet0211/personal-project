/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fu.testing.lab;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author triet
 */
public class DateTimeCheckerLibExceptionTest {

    public DateTimeCheckerLibExceptionTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of checkDayInMonth method, of class DateTimeCheckerLib.
     */
    @Test(expected = Exception.class)
    public void testCheckDayInMonth1() {
        System.out.println("Code: DIM20");
        Object month = "";
        Object year = "123a";
        DateTimeCheckerLib instance = new DateTimeCheckerLib();
        Object expResult = 0;
        int result = instance.checkDayInMonth((Integer) month, (Integer) year);
        assertEquals(expResult, result);
    }

    @Test(expected = Exception.class)
    public void testCheckDayInMonth2() {
        System.out.println("Code: DIM21");
        Object month = 13;
        Object year = "";
        DateTimeCheckerLib instance = new DateTimeCheckerLib();
        Object expResult = 0;
        int result = instance.checkDayInMonth((Integer) month, (Integer) year);
        assertEquals(expResult, result);
    }

    @Test(expected = Exception.class)
    public void testCheckDayInMonth3() {
        System.out.println("Code: DIM22");
        Object month = 11;
        Object year = "";
        DateTimeCheckerLib instance = new DateTimeCheckerLib();
        Object expResult = 0;
        int result = instance.checkDayInMonth((Integer) month, (Integer) year);
        assertEquals(expResult, result);
    }

    @Test(expected = Exception.class)
    public void testCheckDayInMonth4() {
        System.out.println("Code: DIM23");
        Object month = "ab12";
        Object year = 1999;
        DateTimeCheckerLib instance = new DateTimeCheckerLib();
        Object expResult = 0;
        int result = instance.checkDayInMonth((Integer) month, (Integer) year);
        assertEquals(expResult, result);
    }

    /**
     * Test of validDate method, of class DateTimeCheckerLib.
     */
    @Test(expected = Exception.class)
    public void testValidDate1() {
        System.out.println("Code: DAT15");
        Object day = "";
        Object month = 0;
        Object year = 0;
        DateTimeCheckerLib instance = new DateTimeCheckerLib();
        boolean expResult = false;
        boolean result = instance.validDate((Integer) day, (Integer) month, (Integer) year);
        assertEquals(expResult, result);
    }

    @Test(expected = Exception.class)
    public void testValidDate2() {
        System.out.println("Code: DAT16");
        Object day = "a";
        Object month = 0;
        Object year = 0;
        DateTimeCheckerLib instance = new DateTimeCheckerLib();
        boolean expResult = false;
        boolean result = instance.validDate((Integer) day, (Integer) month, (Integer) year);
        assertEquals(expResult, result);
    }

}
